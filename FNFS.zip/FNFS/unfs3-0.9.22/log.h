#ifndef _LOG_H_
#define _LOG_H_

#include <syslog.h>

/* DEFAULT LOG_WARNING */
//#define CLNTLIB_LOGLEVEL (LOG_DEBUG+1)
#define CLNTLIB_LOGLEVEL 0
#if CLNTLIB_LOGLEVEL >=	LOG_DEBUG
#  define DEBUG(fmt, args...) syslog(LOG_ERR, fmt, ##args)
#else
#  define DEBUG(fmt, args...) do{}while(0)
#endif

#endif
