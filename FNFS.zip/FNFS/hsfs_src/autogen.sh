#!/bin/sh

autoreconf -ivf
