/*hsi_nfs3_read.c*/

#ifndef FNFS
#define FNFS 1
#endif 

#include <errno.h>
#include "hsi_nfs3.h"
#include "log.h"

#if FNFS
#include <zlib.h>
int uncompress_data(char * defd, int defd_len, char * infd, int infd_len) {
    
    DEBUG("Inflating: Compressed size is: %lu\n", defd_len);
    DEBUG("defd_len = %d | infd_len = %d", defd_len, infd_len);
    z_stream infstream;
    infstream.zalloc = Z_NULL;
    infstream.zfree = Z_NULL;
    infstream.opaque = Z_NULL;
    infstream.avail_in = (uInt)defd_len; // size of input
    infstream.next_in = defd; // input char array
    infstream.avail_out = (uInt)infd_len; // size of output
    infstream.next_out = (Bytef *)infd; // output char array

    inflateInit(&infstream);
    inflate(&infstream, Z_NO_FLUSH);
    inflateEnd(&infstream);  
    
    DEBUG("Inflating: Uncompressed size is: %lu\n", infstream.total_out);
//    DEBUG("Record: %s", infd);
    return infstream.total_out;
}
#endif 

int hsi_nfs3_read(struct hsfs_rw_info* rinfo, uid_t xid)
{
        #define NFS_MAXDATA_TCP 524288

	struct hsfs_super *sb = rinfo->inode->sb;
	CLIENT *clnt = sb->clntp;
	struct read3args args;
	struct read3res res;
	struct read3resok * resok = NULL;
	int err = 0;
#if FNFS
	int rlen, r, nr_rec, i, bytes;
	char *out_ptr, *in_ptr, *lf_ptr;
	int *rlen_vect;
	int rl;
    char dummy;
	int match;
    int uncompressed_data_len;
static  char uncompressed_data[NFS_MAXDATA_TCP + 1];

#endif /* FNFS*/
	
	DEBUG_IN("offset 0x%x size 0x%x ", (unsigned int)rinfo->rw_off,
		(unsigned int)rinfo->rw_size);

	memset(&args, 0, sizeof(args));
	memset(&res, 0, sizeof(res));

	hsi_nfs3_getfh3(rinfo->inode, &args.file);

	args.offset = rinfo->rw_off;
	args.count = rinfo->rw_size;
	
#if FNFS
        
	/***********************************/
	/* INPUT PARAMETER FOR FILTER	*/
	/***********************************/
        if(getenv("FNFS_FILENAME") != NULL) {
            DEBUG("hsi_nfs3_read ENV VAR FNFS_FILENAME = %s", getenv("FNFS_FILENAME"));
            args.fnfs_fname = getenv("FNFS_FILENAME");
        } else {
            DEBUG("hsi_nfs3_read ENV VAR [FNFS_FILENAME] not set.");
            args.fnfs_fname = "";
        }
        if(getenv("FNFS_FILTER") != NULL) {
            DEBUG("hsi_nfs3_read ENV VAR FNFS_FILTER = %s", getenv("FNFS_FILTER"));
            strcpy( &args.fnfs_filter, getenv("FNFS_FILTER"));
        } else {
            DEBUG("hsi_nfs3_read ENV VAR [FNFS_FILTER] not set.");
            strcpy( &args.fnfs_filter, "");
        }   
        
        if(getenv("FNFS_UID") != NULL) {
            DEBUG("hsi_nfs3_read ENV VAR FNFS_UID = %s", getenv("FNFS_UID"));
            args.fnfs_uid = atoi(getenv("FNFS_UID"));
        } else {
            DEBUG("hsi_nfs3_read ENV VAR [FNFS_UID] not set.");
            args.fnfs_uid = 0;
        }    
        
        if(getenv("FNFS_RLEN") != NULL) {
            DEBUG("hsi_nfs3_read ENV VAR FNFS_RLEN = %s", getenv("FNFS_RLEN"));
            args.fnfs_rlen = atoi(getenv("FNFS_RLEN"));
        } else {
            DEBUG("hsi_nfs3_read ENV VAR [FNFS_RLEN] not set.");
            args.fnfs_rlen = -1;
        } 
        
        if(getenv("FNFS_DUMMY") != NULL) {
            DEBUG("hsi_nfs3_read ENV VAR FNFS_DUMMY = %s", getenv("FNFS_DUMMY"));
            dummy = getenv("FNFS_DUMMY")[0];
        } else {
            DEBUG("hsi_nfs3_read ENV VAR [FNFS_DUMMY] not set.");
            dummy = '#';
        }        

        if(getenv("FNFS_MATCH") != NULL) {
            match = atoi(getenv("FNFS_MATCH"));
			if( match < FNFS_NOFILTER || match > FNFS_FALSE) {
				match = FNFS_MATCH;
				args.fnfs_type = FNFS_MATCH;
			} else {
				args.fnfs_type = match;
			}
            DEBUG("hsi_nfs3_read ENV VAR FNFS_MATCH = %s (match=%d)", getenv("FNFS_MATCH"), match);
        } else {
            DEBUG("hsi_nfs3_read ENV VAR [FNFS_MATCH] not set.");
			match = FNFS_MATCH; 
			args.fnfs_type = FNFS_MATCH; /* MATCH by default */
        } 

        if(getenv("FNFS_COMPRESS") != NULL) {
            DEBUG("hsi_nfs3_read ENV VAR FNFS_COMPRESS = %s", getenv("FNFS_COMPRESS"));
            if( atoi(getenv("FNFS_COMPRESS")))
				args.fnfs_type |= COMPRESSION_MASK;
		} else {
			/*  NO compress by default */
			DEBUG("hsi_nfs3_read ENV VAR [FNFS_COMPRESS] not set.");
		}
        

	rlen = args.fnfs_rlen;
	args.fnfs_xid = xid;  
	DEBUG("hsi_nfs3_read FILE=[%s]", &args.file);
	DEBUG("hsi_nfs3_read FNAME=[%s]", args.fnfs_fname);
	DEBUG("hsi_nfs3_read UID=[%d]", args.fnfs_uid);
	DEBUG("hsi_nfs3_read XID=[%d]", args.fnfs_xid);
	DEBUG("hsi_nfs3_read COUNT=%ld OFFSET=%ld", args.count, args.offset);
	DEBUG("hsi_nfs3_read FILTER type=%X rlen=%d [%s]", 
			args.fnfs_type, args.fnfs_rlen, &args.fnfs_filter);

#endif /*------------------------------- FNFS ----------------------------------*/
	
	err = hsi_nfs3_clnt_call(sb, clnt, NFSPROC3_READ,
				(xdrproc_t)xdr_read3args, (char *)&args,
				(xdrproc_t)xdr_read3res, (char *)&res);
	if (err)
		goto out;

#ifdef HSFS_NFS3_TEST
	err = res.status;
#else
	err = hsi_nfs3_stat_to_errno(res.status);
#endif
	if(!err){
		resok = &res.read3res_u.resok;
		DEBUG("hsi_nfs3_read 0x%x done eof: %d",
				resok->count, resok->eof);
#if FNFS /*------------------------------- FNFS ----------------------------------*/
		DEBUG("hsi_nfs3_read RESULT %X", resok->fnfs_resok);
		DEBUG("hsi_nfs3_read POS %d", resok->fnfs_pos);
		DEBUG("hsi_nfs3_read COUNT  %ld", resok->count);
		DEBUG("hsi_nfs3_read DATA_LEN %ld", resok->data.data_len);

		if( resok->fnfs_resok == FNFS_NOFILTER){
			memcpy(rinfo->data.data_val, resok->data.data_val,
				resok->data.data_len);
			rinfo->data.data_len = resok->data.data_len;
		}else if( (resok->fnfs_resok & ~COMPRESSION_MASK) == FNFS_NOMATCH){
			memset(rinfo->data.data_val,dummy,resok->count);
			rinfo->data.data_len = resok->count;
		}else if( (resok->fnfs_resok  & ~COMPRESSION_MASK) == FNFS_MATCH){
			
			if( (resok->fnfs_resok  & COMPRESSION_MASK) == COMPRESSION_MASK) { /* Compression Enable */
	            // Uncompress
        	    DEBUG("hsi_nfs3_read Compressed DATA_LEN %ld", resok->data.data_len);
//		             	bzero(uncompressed_data, sizeof uncompressed_data);
            	uncompressed_data_len = uncompress_data(resok->data.data_val,
                    	resok->data.data_len, uncompressed_data,
                    	sizeof uncompressed_data);
            	DEBUG("hsi_nfs3_read UnCompressed DATA_LEN %ld",
                    	uncompressed_data_len);
				rlen_vect = uncompressed_data;  			/* record length vector  			*/	
            }else{
        	    DEBUG("hsi_nfs3_read DATA_LEN %ld", resok->data.data_len);
//		            	memcpy(uncompressed_data,resok->data.data_val, resok->data.data_len);
				uncompressed_data_len = resok->data.data_len;
				rlen_vect = resok->data.data_val;  			/* record length vector  			*/
			}

			in_ptr = ((char *) rlen_vect) + resok->fnfs_pos; /* input buffer of matching records 	*/
//			DEBUG("%s", in_ptr);
			out_ptr = rinfo->data.data_val; 			/* output data pointer -> to NFS client	 */
			nr_rec = resok->fnfs_pos/sizeof(unsigned int);/* Number of records  			*/
			DEBUG("hsi_nfs3_read nr_rec=%d", nr_rec);
			bytes = 0;
			for( r = 0 ; r < nr_rec; r++){
				DEBUG("hsi_nfs3_read received rlen_vect[%d]=%d",r, rlen_vect[r]);
				if( rlen_vect[r] > 0) {			/* record does not MATCH		*/
					memset(out_ptr,dummy, rlen_vect[r]-1 ); /* Fill with DUMMY data		*/
					out_ptr += rlen_vect[r];
					*(out_ptr-1) = '\n';			/*final  LF 						*/
				}else{                              /* matching record				*/			
					memcpy(out_ptr, in_ptr, abs(rlen_vect[r]));  /* copy from input buffer to output buffer */
					in_ptr += abs(rlen_vect[r]);
					out_ptr += abs(rlen_vect[r]);
				}
				bytes += abs(rlen_vect[r]);
			}
			DEBUG("hsi_nfs3_read received bytes=%d",bytes);
			rinfo->data.data_len = bytes;
		}else{
			fprintf(stderr, "hsi_nfs3_read error bad result received %d\n", resok->fnfs_resok);
			syslog(LOG_ERR, "hsi_nfs3_read error bad result received %d" , resok->fnfs_resok); 
			exit(1);
		}
		rinfo->ret_count = rinfo->data.data_len;
#else /* FNFS*/
		memcpy(rinfo->data.data_val, resok->data.data_val,
			resok->data.data_len);
		rinfo->data.data_len = resok->data.data_len;
		rinfo->ret_count = resok->count;
#endif /* FNFS*/
		rinfo->eof = resok->eof;
		DEBUG("resok->file_attributes.present: %d",
			resok->file_attributes.present);
/* 		if(resok->file_attributes.present) */
/* 			memcpy(&rinfo->inode->attr, */
/* 				&resok->file_attributes.post_op_attr_u.attributes, */
/* 				sizeof(fattr3)); */
	}else{
		ERR("hsi_nfs3_read failure: %d", err);
/* 		if(res.read3res_u.resfail.present) */
/* 			memcpy(&rinfo->inode->attr, */
/* 				&res.read3res_u.resfail.post_op_attr_u.attributes, */
/* 				sizeof(fattr3)); */
	}
	
	clnt_freeres(clnt, (xdrproc_t)xdr_read3res, (char *)&res);

out:
	DEBUG_OUT("err %d", err);
	return err;
}

#ifdef HSFS_NFS3_TEST

int main(int argc, char *argv[])
{
	struct hsfs_rw_info rinfo;
	struct hsfs_inode inode;
	struct hsfs_super sblock;
	char *svraddr = NULL;
	char *fpath = NULL;
	char *mpoint = NULL;
	CLIENT *clntp = NULL;
	size_t fhlen = 0 ;
	unsigned char *fhvalp = NULL;
	size_t iosize = 0;
	int err = 0;
	
	if(argc != 5){
		printf("USEAGE: hsi_nfs3_read  SERVER_IP   FILEPATH   IOSIZE   "
			"MOUNTPOINT\n");
		printf("EXAMPLE: ./hsi_nfs3_read    10.10.99.120   "
			"/nfsXport/file   512  /mnt/hsfs\n");
		err = EINVAL;
		goto out;
	}
	
	svraddr = argv[1];
	fpath = argv[2];
	iosize = atoi(argv[3]);
	if(0 == iosize)
		printf("IOSIZE is zero\n");
	mpoint = argv[4];
	clntp = clnt_create(svraddr, NFS_PROGRAM, NFS_V3, "TCP");
	if(NULL == clntp) {
		printf("Create handle to RPC server (%s, %u, %u) failed\n",
			svraddr, NFS_PROGRAM, NFS_V3);
		err = EREMOTEIO;
		goto out;
	}

	err = map_path_to_nfs3fh(svraddr, fpath, &fhlen, &fhvalp);
	if(err)
	{
		printf("map_path_to_nfs3fh error: %s.\n", strerror(err));
		err = ENXIO;		
		goto out;
	}
	
	memset(&inode, 0, sizeof(struct hsfs_inode));
	memset(&rinfo, 0, sizeof(struct hsfs_rw_info));
	memset(&sblock, 0, sizeof(struct hsfs_super));
	inode.sb = &sblock;
	rinfo.inode = &inode;
	
	sblock.timeo = 1200;//120sec
	sblock.clntp = clntp;
	inode.fh.data.data_len = fhlen;
	inode.fh.data.data_val = fhvalp;
	
	rinfo.rw_off = 0;
	rinfo.rw_size = iosize;

	while(1){
		rinfo.rw_off += rinfo.ret_count;
		err = hsi_nfs3_read(&rinfo);
		if(err)
			break;
		
		if(rinfo.eof)
			break;		
	}

out:
	return err;
}

#endif /*HSFS_NFS3_TEST*/
